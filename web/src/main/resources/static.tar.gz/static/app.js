(function () {
    console.log('2qlasdasdadasdqlql');
}());